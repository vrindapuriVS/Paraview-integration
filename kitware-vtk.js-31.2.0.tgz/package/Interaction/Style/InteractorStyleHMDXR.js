import { m as macro } from '../../macros2.js';
import vtkInteractorStyleManipulator from './InteractorStyleManipulator.js';
import vtk3DControllerModelSelectorManipulator from '../Manipulators/3DControllerModelSelectorManipulator/index.js';
import { Device, Input } from '../../Rendering/Core/RenderWindowInteractor/Constants.js';

function vtkInteractorStyleHMDXR(publicAPI, model) {
  model.classHierarchy.push('vtkInteractorStyleHMDXR');
  const leftHandManipulator = vtk3DControllerModelSelectorManipulator.newInstance({
    device: Device.LeftController,
    input: Input.A
  });
  const rightHandManipulator = vtk3DControllerModelSelectorManipulator.newInstance({
    device: Device.RightController,
    input: Input.A
  });
  publicAPI.addVRManipulator(leftHandManipulator);
  publicAPI.addVRManipulator(rightHandManipulator);
}

// ----------------------------------------------------------------------------
// Object factory
// ----------------------------------------------------------------------------

const DEFAULT_VALUES = {};

// ----------------------------------------------------------------------------

function extend(publicAPI, model) {
  let initialValues = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  Object.assign(model, DEFAULT_VALUES, initialValues);

  // Inheritance
  vtkInteractorStyleManipulator.extend(publicAPI, model, initialValues);

  // Object specific methods
  vtkInteractorStyleHMDXR(publicAPI, model);
}

// ----------------------------------------------------------------------------

const newInstance = macro.newInstance(extend, 'vtkInteractorStyleHMDXR');

// ----------------------------------------------------------------------------

var index = {
  newInstance,
  extend
};

export { index as default, extend, newInstance };
