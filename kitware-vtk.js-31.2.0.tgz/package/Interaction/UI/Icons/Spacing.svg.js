var svgSpacing = "<svg viewBox=\"0 0 180 180\" xmlns=\"http://www.w3.org/2000/svg\"><g stroke=\"#000\" stroke-width=\"10\" fill=\"none\" fill-rule=\"evenodd\" stroke-linecap=\"square\"><path d=\"M10 90h160M10 133.488V47M170 133.488V47M90 133.488V47\"/></g></svg>";

export { svgSpacing as s };
